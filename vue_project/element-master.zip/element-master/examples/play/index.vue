<template>
  <div style="margin: 20px;">
    <!-- Write your component in component.vue -->
    <play-component></play-component>
  </div>
</template>
<script>
  import PlayComponent from './component.vue';
  export default {
    components: {
      PlayComponent
    }
  };
</script>
