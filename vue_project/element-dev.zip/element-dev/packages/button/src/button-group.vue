<template>
  <div class="el-button-group">
    <slot></slot>
  </div>
</template>
<script>
  /**
   * button
   * @module components/basic/menu
   * @desc 用于按钮组
   * @param {string} label - 名称
   */
  export default {
    name: 'ElButtonGroup'
  };
</script>
